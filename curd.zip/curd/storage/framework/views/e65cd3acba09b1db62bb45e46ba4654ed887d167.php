<?php /* C:\xampp\htdocs\curd\resources\views/session.blade.php */ ?>


<form method="post" action="<?php echo e(URL::to('/submit')); ?>">

<input type="text" name="name"><br>
<br>
<input type="submit" name="submit" value="submit">
</form>