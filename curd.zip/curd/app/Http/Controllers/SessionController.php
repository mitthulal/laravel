<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;


class SessionController extends Controller
{
    
    	 public function index()
    {
 return view('/session');
}
    public function show(Request $req)
    {
    	// print_r($req->input());
    	$req->session()->flash('user',$req->input('name'));
    	 
    	return view('welcome')->with('data',$req->session()->get('user'));
    }
}
    	?>



