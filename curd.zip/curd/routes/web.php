<?php

Route::get('/', function () {
    return view('welcome');
});

Route::resource('books', 'BookController');


Route::post('/login', 'SessionController@show');
Route::get('/session', 'SessionController@index');
Route::get('/login', function(){

	return view('login');
});