

<form method="post" action="{{URL::to('/login')}}">
@csrf
<input type="text" name="name"><br>
<br>
<input type="submit" name="submit" value="submit">
</form>
