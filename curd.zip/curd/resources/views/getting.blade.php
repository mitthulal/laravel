

<form method="post" action="{{ URL::to('/submit')}}">

<input type="text" name="name"><br>
<br>
<button type="submit">submit</button>
</form>